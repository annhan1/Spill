package com.ch.space.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ch.space.model.Activity;

@Repository
public class JoinactDaoImpl implements JoinactDao{
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public void insert(Activity activity) {
		sst.insert("joinactns.insert", activity);
	}
}
