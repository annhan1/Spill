package com.ch.space.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.space.dao.ScoreDao;
import com.ch.space.model.Score;

@Service
public class ScoreServiceImpl implements ScoreService {
	
	@Autowired
	private ScoreDao sd;

	@Override
	public int insertUpdate(Score newScore) {
		int result = 0;
		Score score = sd.selectByCatMem(newScore);
		
		if (score!=null) {
			newScore.setScore_id(score.getScore_id());
			result = sd.update(newScore);
			result = 100;
		} else {
			result = sd.insert(newScore);
		}
		return result;
	}

	@Override
	public List<Score> list(int member_id) {
		return sd.list(member_id);
	}

	@Override
	public List<Score> listByCat(Score score) {
		// list of all members with score for cat_id (except for user)
		List<Score> longList = sd.listEveryone(score);
		
		// members who have been recommended to user but have been declined by user
		List<Score> newmatchDelList = sd.listNewMatchesDeclined(score);
		
		// members who are already friends with user
		List<Score> removeList = sd.listSelectively(score);
		
		// remove removeList from longList
		List<Score> recList = new ArrayList<Score>();
		for (int i=0;i<longList.size();i++) {
			int mustRemove = 0;
			for (int j=0;j<removeList.size();j++) {
				if (longList.get(i).getMember_id()==removeList.get(j).getConn_friend1_id()||
						longList.get(i).getMember_id()==removeList.get(j).getConn_friend1_id()) {
					mustRemove++;
				}
					
			}

			for (int j=0;j<newmatchDelList.size();j++) {
				if (longList.get(i).getMember_id()==newmatchDelList.get(j).getNewmatch_friend1_id()||
						longList.get(i).getMember_id()==newmatchDelList.get(j).getNewmatch_friend2_id()) {
					mustRemove++;
				}
			}
			if (mustRemove==0) recList.add(longList.get(i)); 
		}
		return recList;
	}
	

}
