package com.ch.space.service;

import java.util.List;

import com.ch.space.model.Newmatch;

public interface NewmatchService {

	void insert(Newmatch nm);

	List<Newmatch> selectMatched(int member_id);

	int updateDel(Newmatch nm);

}
