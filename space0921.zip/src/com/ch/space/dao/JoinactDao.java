package com.ch.space.dao;

import com.ch.space.model.Activity;

public interface JoinactDao {

	void insert(Activity activity);

}
