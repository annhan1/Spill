package com.ch.space.service;

import java.util.List;

import com.ch.space.model.Choice;

public interface ChoiceService {

	List<Choice> selectByQuiz(int quiz_id);

}
