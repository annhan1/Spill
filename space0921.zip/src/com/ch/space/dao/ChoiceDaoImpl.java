package com.ch.space.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ch.space.model.Choice;

@Repository
public class ChoiceDaoImpl implements ChoiceDao {
	
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public List<Choice> selectByQuiz(int quiz_id) {
		return sst.selectList("choicens.selectByQuiz", quiz_id);
	}
}
