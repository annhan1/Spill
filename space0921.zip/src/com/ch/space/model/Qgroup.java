package com.ch.space.model;

import java.sql.Date;

import lombok.Data;

@Data
public class Qgroup {
	private int qgroup_id;
	private int member_id;
	private String qgroup_temp_member;
	private int cat_id;
	private Date qgroup_reg_date;
}
