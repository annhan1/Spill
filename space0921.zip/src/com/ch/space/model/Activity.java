package com.ch.space.model;

import java.sql.Date;

import lombok.Data;

@Data
public class Activity {
	private int activity_id;
	private int activity_host_id;
	private String activity_title;
	private String activity_challenge;
	private int activity_max;
	private String activity_public;
	private Date activity_begin;
	private Date activity_end;
	private String activity_desc;
	private Date activity_reg_date;
	private String activity_img;
	private String activity_alert;
	private String activity_del;
	
	//조인용
	private String member_nickname; //activity_host_id에 해당하는 회원 닉네임
	private int cnt_reply; //댓글 수
	private int cnt_joiner; //활동 참여자 수 
}
