package com.ch.space.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AlertDaoImpl implements AlertDao {
	@Autowired
	private SqlSessionTemplate sst;
}
