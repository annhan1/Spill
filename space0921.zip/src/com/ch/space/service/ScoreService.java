package com.ch.space.service;

import java.util.List;

import com.ch.space.model.Score;

public interface ScoreService {

	int insertUpdate(Score newScore);

	List<Score> list(int member_id);

	List<Score> listByCat(Score score);

}
