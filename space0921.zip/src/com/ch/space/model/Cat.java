package com.ch.space.model;

import lombok.Data;

@Data
public class Cat {
	private int cat_id;
	private String cat_name;
	private String cat_same;
	private String cat_simple;
}
