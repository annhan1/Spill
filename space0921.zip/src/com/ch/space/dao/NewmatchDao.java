package com.ch.space.dao;

import java.util.List;

import com.ch.space.model.Newmatch;

public interface NewmatchDao {

	void insert(Newmatch nm);

	List<Newmatch> selectMatched(int member_id);

	int updateDel(Newmatch nm);

}
