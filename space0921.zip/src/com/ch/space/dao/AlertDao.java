package com.ch.space.dao;

public interface AlertDao {

}
