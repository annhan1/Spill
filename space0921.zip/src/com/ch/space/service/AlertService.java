package com.ch.space.service;

public interface AlertService {

}
