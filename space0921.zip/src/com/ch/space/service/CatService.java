package com.ch.space.service;

import com.ch.space.model.Cat;

public interface CatService {

	Cat select(int cat_id);

	int randomCat(int cat_id);

}
