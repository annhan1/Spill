package com.ch.space.model;

import lombok.Data;

@Data
public class Joinact {
	private int activity_id;
	private int member_id;
	private String joinact_del;
	private String joinact_block;
}
