package com.ch.space.model;

import lombok.Data;

@Data
public class Img {
	private int img_id;
	private int member_id;
	private String img_path;
}
