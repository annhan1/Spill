package com.ch.space.dao;

import java.util.List;
import java.util.Map;

import com.ch.space.model.Activity;
import com.ch.space.service.Criteria;

public interface ActivityDao {

	List<Activity> getList(Map<String, Object> map);

	int getTotal(Criteria cri);

	void insert(Activity activity);

	Activity getDetail(int activity_id);

	Activity selectRecent(int activity_host_id);

	public int cnt_reply(int activity_id);
	
	public int cnt_joiner(int activity_id);

}
