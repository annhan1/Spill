package com.ch.space.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.space.dao.JoinactDao;
import com.ch.space.model.Activity;


@Service
public class JoinactServiceImpl implements JoinactService{
	@Autowired
	private JoinactDao jd;

	@Override
	public void insert(Activity activity) {
		jd.insert(activity);
	}

}
