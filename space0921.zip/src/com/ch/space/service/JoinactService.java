package com.ch.space.service;

import com.ch.space.model.Activity;

public interface JoinactService {

	void insert(Activity activity);

}
