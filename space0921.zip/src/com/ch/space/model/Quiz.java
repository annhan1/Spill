package com.ch.space.model;

import java.util.List;

import lombok.Data;

@Data
public class Quiz {
	private int quiz_id;
	private int cat_id;
	private String quiz_title;
	private String quiz_level;
	private int choice_id1;
	private int choice_id2;
	private String choice_content1;
	private String choice_content2;
	private int choice_point1;
	private int choice_point2;
	
	// to transfer list of questions already answered
	private List<Integer> quizList; 
}
