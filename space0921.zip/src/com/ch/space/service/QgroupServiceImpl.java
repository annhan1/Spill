package com.ch.space.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.space.dao.QgroupDao;
import com.ch.space.model.Qgroup;

@Service
public class QgroupServiceImpl implements QgroupService {
	
	@Autowired
	private QgroupDao qd;
	
	@Override
	public List<Qgroup> list(int member_id) {
		return qd.list(member_id);
	}

	@Override
	public int insertMain(Qgroup qgroup) {
		return qd.insertMain(qgroup);
	}

	@Override
	public Qgroup selectRecent(String ip) {
		return qd.selectRecent(ip);
	}

	@Override
	public Qgroup select(int qgroup_id) {
		return qd.select(qgroup_id);
	}

	@Override
	public void updateMemInfo(Qgroup qgroup) {
		qd.updateMemInfo(qgroup);
	}
}
