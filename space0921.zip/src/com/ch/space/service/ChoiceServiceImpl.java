package com.ch.space.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.space.dao.ChoiceDao;
import com.ch.space.model.Choice;

@Service
public class ChoiceServiceImpl implements ChoiceService {
	
	@Autowired
	private ChoiceDao cd;

	@Override
	public List<Choice> selectByQuiz(int quiz_id) {
		return cd.selectByQuiz(quiz_id);
	}
}
