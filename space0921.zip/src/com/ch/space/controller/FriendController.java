package com.ch.space.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ch.space.model.Cat;
import com.ch.space.model.Conn;
import com.ch.space.model.History;
import com.ch.space.model.Member;
import com.ch.space.model.Newmatch;
import com.ch.space.model.Qgroup;
import com.ch.space.model.Quiz;
import com.ch.space.model.Score;
import com.ch.space.service.CatService;
import com.ch.space.service.ConnService;
import com.ch.space.service.HistoryService;
import com.ch.space.service.MemberService;
import com.ch.space.service.NewmatchService;
import com.ch.space.service.QgroupService;
import com.ch.space.service.QuizService;
import com.ch.space.service.ScoreService;

@Controller
public class FriendController {
	@Autowired
	private MemberService ms;
	@Autowired
	private CatService cs;
	@Autowired
	private QuizService qs;
	@Autowired
	private HistoryService hs;
	@Autowired
	private QgroupService qgs;
	@Autowired
	private ScoreService ss;
	@Autowired
	private NewmatchService ns;
	@Autowired
	private ConnService cos;
	                                                                                                                                    
	@RequestMapping("/friendLogic")
	public String initFriendLogic() {
		return "redirect:friendLogic/1";
	}
	@RequestMapping("/friendLogic/{member_id}")
	public String friendLogic(@PathVariable int member_id, Model model) {
		// people will only be answering two categories at a time so need to check which category
		// if cat_simple = 'y': compare to other users to see which user has highest match choices
		// if cat_simple = 'n':
		// make sure code checks if there arent't two answers for question - multiples of two
		
		// when calling answers, to prevent cases where user has answered question twice - call most recent
		// 1. conduct complete match check like above --> this will provide a score for overall similarity 
		//		between two users
		// 2. calculate score for categories with cat_simple='n'
		// 3. compare score to other user's scores - > may have to make score table
		// 		if cat_same = 'y': similar score is best result. lif score same make sure age is closer
		//		if cat_same = 'n': do not compare score to other user's scores
		//							however, people find mbti opposites to be attractive, so
		//							do not consider this as a key factor but introduce if 
		//							complete opposite MBTI. otherwise just consider as fun fact / overall score
		//		if cat_name = '愿�醫낆��닔': do not match the two if the score is double one another
		
		// question: like instagram and such should looking up others by their nicknames be allowed?
		// i think yes --> then member needs additional column: 鍮꾧났媛� 怨듦컻
		// you can add people by requesting to add them but when it comes to friend match, we will limit age
		// difference to +-10 years
		// i feel like people should have active points --> the more active you are, the more friend suggestions
		// you can get
		// how do you calculate activeness though? how recently you participated in an activity, the last
		// time you logged in , the date you last updated your posts
		// if your active score is below certain point then don't offer new matches - other people don't get
		// you as their new match
		
		// preallocating space
		int answered = 0;
		int score_num = 0;
		int sameAnswers = 0;
		Double saveNum = 100.0000;
		int saveId = 0;
		int number = 0;
		int recommendedTimes = 1;
		int resultScoreInsert = 0;
		
		////////////////////////////////////////////////////////////////////////////////////////////////
		// STEP 1: Calculate score for each category
		// 		   If member has answered same category questions before, must take into account
		
		// 1. Read quiz group history ordered by most recent for above member (read two quiz groups only)
		List<Qgroup> qgroupList = qgs.list(member_id);
		
		// 2. Read history and calculate score for each quiz group
		for (int i=0;i<qgroupList.size();i++) {
			// 1) Read quiz group's category information and list up questions associated with cat_id
			Cat cat = cs.select(qgroupList.get(i).getCat_id());
			List<Quiz> quizList = qs.listByCat(qgroupList.get(i).getCat_id());
			
			// 2) List history associated with cat_id
			List<History> historyList = hs.listByCat(qgroupList.get(i)); //check
			
			// 3) Create Score model to save information
			Score newScore = new Score();
			newScore.setCat_id(qgroupList.get(i).getCat_id());
			newScore.setMember_id(member_id);
			
			// 4) Based on cat_simple, decide score to record
			if (cat.getCat_simple().contentEquals("y")) { // record string score
				String score_comp = "";
				for (Quiz quiz:quizList) {
					answered = 0;
					for (History history:historyList) {
						if (quiz.getQuiz_id() == history.getQuiz_id()) {
							answered=history.getChoice_id();
						} 
					}
					// if question was answered, record answer
					if (answered!=0) score_comp += answered+"_";
					// if question was not answered, record zero
					else score_comp += "0_";
				}
				newScore.setScore_comp(score_comp);
				newScore.setScore_num("not");
			} else { // record number score
				score_num = 0;
				for (History history:historyList) {
					score_num += history.getChoice_point();
				}
				// record (sum of points)/(total points possible)
				newScore.setScore_num(((double)score_num/(double)historyList.size()+"")); //should divide by number of questions solved
			}
			// 5) Upload score to database
			resultScoreInsert += ss.insertUpdate(newScore);
		}
		
		System.out.println("completed step 1");
		String returnString = "";
		if (resultScoreInsert>=2) {
		////////////////////////////////////////////////////////////////////////////////////////////////
		// STEP 2: Compare calculated scores to other users to find friends
		// 		   Must take into consideration that other members may not have answered certain questions
		//		   and how similarity score should factor in how members have answered different questions
		
		// 1. Call for member's scores
		List<Score> scoreList = ss.list(member_id);
		
		// 2. Preallocate space to save friends recommended 
		Map<Integer, Integer> friendsRecommendedComp = new HashMap<Integer, Integer>();
		Map<Integer, Integer> friendsRecommendedNum = new HashMap<Integer, Integer>();

		// 3. For each score, compare to other members and record list of members in order
		for (int i=0;i<scoreList.size();i++) {

			// 1) Identify category
			Cat scoreCat = cs.select(scoreList.get(i).getCat_id());
			
			// 2) Call other scores with same cat_id, not the same member_id as user and make sure not to 
			//		include those who are already friends and those who have been declined as friends
			List<Score> sameCatScores = ss.listByCat(scoreList.get(i));
			
			// 3) Compare scores depending on cat_simple and cat_same
			if (scoreCat.getCat_simple().equals("y")) { // must compare score_comp
				String[] myScore = scoreList.get(i).getScore_comp().split("_");
				

				// if score length is not the same, compare until other user's last question
				for (int j=0;j<sameCatScores.size();j++) {
					String[] friendScore = sameCatScores.get(j).getScore_comp().split("_");
					sameAnswers = 0;
					if (friendScore.length<=myScore.length) {
						for (int k=0;k<friendScore.length;k++) {
							if (friendScore[k].equals(myScore[k])) {
								sameAnswers++;
							}
						}
					}

					// if member already in recommended list, find member and add up scores to save
					if (friendsRecommendedComp.containsKey(sameCatScores.get(j).getMember_id())) {
						sameAnswers+=friendsRecommendedComp.get(sameCatScores.get(j).getMember_id());
					}

					friendsRecommendedComp.put(sameCatScores.get(j).getMember_id(), sameAnswers);
				}	
			} else if (scoreCat.getCat_simple().equals("n")) { // must compare score_num
				//if (scoreCat.getCat_same().equals("y")) { // similar score_num better
					
					Map<Integer,Double> scoreDiff = new HashMap<Integer, Double>();
					double myScoreNum = Double.parseDouble(scoreList.get(i).getScore_num());
					
					// calculate score difference for each member (difference can be negative)
					for (int j=0;j<sameCatScores.size();j++) {
						double scoreNum = Double.parseDouble(sameCatScores.get(j).getScore_num());
						scoreDiff.put(sameCatScores.get(j).getMember_id(), myScoreNum-scoreNum);
					}
					
					// list members in order of smallest score difference to biggest score difference
					int[] memIdArr = new int[3];

					while (scoreDiff.size()>0||memIdArr[2]!=0) {
						saveNum = 100.0000;
						saveId = 0;
						number = 0;
						for (Entry<Integer, Double> entry:scoreDiff.entrySet()) {
							 if (Math.abs(entry.getValue())<saveNum) {
								 saveNum = entry.getValue();
								 saveId = entry.getKey();
							 }
						}
						System.out.println("saveId: "+saveId);
						scoreDiff.remove(saveId); 
						// save up to three members
						memIdArr[number++] = saveId;
					}
				
					// save top3 in recommended map
					for (int j=0;j<memIdArr.length;j++) {
						// if member already in recommended list, find member and add a point
						recommendedTimes = 1;
						if (friendsRecommendedNum.containsKey(memIdArr[j])) {
							recommendedTimes+=friendsRecommendedNum.get(memIdArr[j]);
						}
						if (memIdArr[j]!=0) {
							System.out.println("memIdArr: "+memIdArr[j]);
							friendsRecommendedNum.put(memIdArr[j], recommendedTimes);
						}
					}
				//} else if (scoreCat.getCat_same().equals("n")) { // need special analyzing
					// not necessarily good to have same personality traits
					// do not recommend if score difference is *8
				//}
			}
		}
		
		System.out.println("completed step 2");
		////////////////////////////////////////////////////////////////////////////////////////////////
		// STEP 3: With list of possible friends, pick out top 5 and try not to include recently 
		// 			recommended friends
		
		int save = 0;
		int dontSave = 0;
		
		// 1. Find recently recommended friends
		List<Newmatch> recentlyMatched = ns.selectMatched(member_id);
		
		// 2. Order friendsRecommendedComp with smallest score_diff first
		//		Exclude differences that are bigger than 20%
		
		int[] memIdComp = new int[5];
		saveId = 0;
		number = 0;
		
		int sameCatNumber = hs.sameCatAnswered(member_id);
		
		while (friendsRecommendedComp.size()>0) {
			saveId = 0;
			save = 0;
			for (Entry<Integer, Integer> entry:friendsRecommendedComp.entrySet()) {
				dontSave = 0;
				for (int i=0;i<recentlyMatched.size();i++) {
					if (recentlyMatched.get(i).getNewmatch_friend1_id()==entry.getKey()||
							recentlyMatched.get(i).getNewmatch_friend2_id()==entry.getKey()) {
						dontSave++;
					}
				}
				System.out.println("here id: "+entry.getKey()+" , don't save = "+dontSave);
				if (entry.getValue()>save&&dontSave==0) {
					save = entry.getValue();
					saveId = entry.getKey();
					System.out.println("inside: saveId="+saveId+", save="+save);
				}
			}
			System.out.println("saveId: "+saveId);
			System.out.println("save: "+save);
			System.out.println("sameCatNumber: "+sameCatNumber);
			if ((double)save/(double)sameCatNumber<0.75) break;
			System.out.println("this id was saved:"+saveId);
			friendsRecommendedComp.remove(saveId);
			memIdComp[number++] = saveId;
			
			if (memIdComp[4]!=0||number==4) break;
		}
		
		// 3. Order friendsRecommendedNum
		int[] memIdNum = new int[10];
		save = 0;
		saveId = 0;
		number = 0;

		while (friendsRecommendedNum.size()>0) {
			saveId = 0;
			save = 0;
			for (Entry<Integer, Integer> entry:friendsRecommendedNum.entrySet()) {
				dontSave = 0;
				 for (int i=0;i<recentlyMatched.size();i++) {
					 if (recentlyMatched.get(i).getNewmatch_friend1_id()==entry.getKey()||
							 recentlyMatched.get(i).getNewmatch_friend2_id()==entry.getKey()) {
						 dontSave++;
					 }
				 }
				 if (entry.getValue()>save&&dontSave==0) {
					 save = entry.getValue();
					 saveId = entry.getKey();
				 }
			}
			friendsRecommendedNum.remove(saveId);
			memIdNum[number++] = saveId;
			
			if (memIdNum[9]!=0||number==9) break;
		}
		
		// 4. Until matchList contains five people, continue to find new matches from recommended friends
		List<Member> matchList = new ArrayList<Member>();
		number = 1;
		int skip = 0;
		int num = 0;
		int comp = 0;
		int repeat = 0;
		
		while (matchList.size()<=5&&skip<5) {
			if ((number++)%2==1) {
				if (num>memIdNum.length-1) skip++; 
				else {
					for (Member match:matchList) {
						if (match.getMember_id()==memIdNum[num]) repeat++;
					}
					if (memIdNum[num]==0||repeat>0) {
						skip++; num++;
						repeat = 0;
					} else {
						skip = 0;
						repeat = 0;
						matchList.add(ms.select(memIdNum[num++]));		
					}
				}
			} else {
				if (comp>memIdComp.length-1) skip++;
				else {
					for (Member match:matchList) {
						if (match.getMember_id()==memIdComp[comp]) repeat++;
					}
					if (memIdComp[comp]==0||repeat>0) {
						skip++; comp++;
						repeat = 0;
					} else {
						skip = 0;
						repeat = 0;
						matchList.add(ms.select(memIdComp[comp++]));
					}
				}
			}
		}
		
		System.out.println("completed step 3");
		////////////////////////////////////////////////////////////////////////////////////////////////
		// STEP 3: Add people in matchList to newMatch table for member
		
		System.out.println(matchList.size());
		for (int i=0;i<matchList.size();i++) {
			System.out.println(member_id+" : "+matchList.get(i).getMember_id());
		}
		
		Newmatch nm = new Newmatch();
		nm.setNewmatch_friend1_id(member_id);
		for (int i=0;i<matchList.size();i++) {
			nm.setNewmatch_friend2_id(matchList.get(i).getMember_id());
			System.out.println();
			ns.insert(nm);
		}
		
		Member member = ms.select(member_id);
		model.addAttribute("matchListSize", matchList.size());
		model.addAttribute("matchList", matchList);
		model.addAttribute("member", member);
		returnString += "friend/newFriend";
		} else {
			returnString += "error";
			model.addAttribute("msg", "점수 등록에 실패했습니다. 다시 한번 시도해주세요.");
		}
		
		return returnString;
	}
	
	@RequestMapping("matchDel/{member_id}/{friend_id}")
	public String matchDel (@PathVariable String member_id, @PathVariable String friend_id, Model model) {
		Newmatch nm = new Newmatch();
		nm.setNewmatch_friend1_id(Integer.parseInt(member_id));
		nm.setNewmatch_friend2_id(Integer.parseInt(friend_id));
		int result = ns.updateDel(nm);
		
		List<Newmatch> newMatchList = ns.selectMatched(Integer.parseInt(member_id));
		List<Member> matchList = new ArrayList<Member>();
		
		System.out.println(newMatchList.size());
		for (int i=0;i<newMatchList.size();i++) {
			if (newMatchList.get(i).getNewmatch_friend1_id()!=Integer.parseInt(member_id)) {
				matchList.add(ms.select(newMatchList.get(i).getNewmatch_friend1_id()));
				System.out.println(newMatchList.get(i).getNewmatch_friend1_id());
			} else {
				matchList.add(ms.select(newMatchList.get(i).getNewmatch_friend2_id()));
				System.out.println(newMatchList.get(i).getNewmatch_friend2_id());
			}
		}
		
		model.addAttribute("result",result);
		Member member = ms.select(Integer.parseInt(member_id));
		model.addAttribute("matchListSize", matchList.size());
		model.addAttribute("matchList", matchList);
		model.addAttribute("member", member);
		
		return "friend/matchResult";
	}
	
	@RequestMapping("matchAdd/{member_id}/{friend_id}")
	public String matchAdd (@PathVariable String member_id, @PathVariable String friend_id, Model model) {
		Newmatch nm = new Newmatch();
		nm.setNewmatch_friend1_id(Integer.parseInt(member_id));
		nm.setNewmatch_friend2_id(Integer.parseInt(friend_id));
		int result = ns.updateDel(nm);
		
		int addResult = 0;
		
		if (result > 0 ) {
			Conn conn = new Conn();
			conn.setConn_friend1_id(Integer.parseInt(member_id));
			conn.setConn_friend2_id(Integer.parseInt(friend_id));
			
			addResult = cos.insert(conn);
		}
		
		List<Newmatch> newMatchList = ns.selectMatched(Integer.parseInt(member_id));
		List<Member> matchList = new ArrayList<Member>();
		
		System.out.println(newMatchList.size());
		for (int i=0;i<newMatchList.size();i++) {
			if (newMatchList.get(i).getNewmatch_friend1_id()!=Integer.parseInt(member_id)) {
				matchList.add(ms.select(newMatchList.get(i).getNewmatch_friend1_id()));
				System.out.println(newMatchList.get(i).getNewmatch_friend1_id());
			} else {
				matchList.add(ms.select(newMatchList.get(i).getNewmatch_friend2_id()));
				System.out.println(newMatchList.get(i).getNewmatch_friend2_id());
			}
		}
		
		model.addAttribute("result",addResult);
		Member member = ms.select(Integer.parseInt(member_id));
		model.addAttribute("matchListSize", matchList.size());
		model.addAttribute("matchList", matchList);
		model.addAttribute("member", member);
		
		return "friend/matchResult";
	}
}