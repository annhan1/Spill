package com.ch.space.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.ch.space.dao.AlertDao;

@Service
public class AlertServiceImpl implements AlertService {
	@Autowired
	private AlertDao ad;
}
