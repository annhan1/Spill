package com.ch.space.model;

import lombok.Data;

@Data
public class Master {
	private int master_id;
	private String master_pass;
}
