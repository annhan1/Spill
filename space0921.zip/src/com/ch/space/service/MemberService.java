package com.ch.space.service;

import com.ch.space.model.Member;

public interface MemberService {

	Member select(int member_id);
	
	Member find(String member_name);
	
	Member select1(String member_nickname);
	
	Member select2(String member_tel);
	
	int insert(Member member);
	
	int update(Member member);
	
	int delete(String member_email);

	int count();

	Member selectEmail(String member_email);
	
	Member getDetail(int member_id);
}
