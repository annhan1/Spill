package com.ch.space.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.space.dao.HistoryDao;
import com.ch.space.model.History;
import com.ch.space.model.Qgroup;

@Service
public class HistoryServiceImpl implements HistoryService {
	
	@Autowired
	private HistoryDao hd;

	@Override
	public List<History> listByCat(Qgroup qgroup) {
		return hd.listByCat(qgroup);
	}

	@Override
	public int sameCatAnswered(int member_id) {
		return hd.sameCatAnswered(member_id);
	}

	@Override
	public int count() {
		return hd.count();
	}

	@Override
	public int insert(History history) {
		return hd.insert(history);
	}

	@Override
	public int countAnswered(int qgroup_id) {
		return hd.countAnswered(qgroup_id);
	}

}
