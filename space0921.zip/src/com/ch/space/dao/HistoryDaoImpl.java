package com.ch.space.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ch.space.model.History;
import com.ch.space.model.Qgroup;

@Repository
public class HistoryDaoImpl implements HistoryDao {
	
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public List<History> listByCat(Qgroup qgroup) {
		return sst.selectList("historyns.listByCat", qgroup);
	}

	@Override
	public int sameCatAnswered(int member_id) {
		return sst.selectOne("historyns.sameCatAnswer", member_id);
	}

	@Override
	public int count() {
		return sst.selectOne("historyns.count");
	}

	@Override
	public int insert(History history) {
		return sst.insert("historyns.insert", history);
	}

	@Override
	public int countAnswered(int qgroup_id) {
		return sst.selectOne("historyns.countAnswered",qgroup_id);
	}

}
