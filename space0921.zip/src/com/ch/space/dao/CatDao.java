package com.ch.space.dao;

import com.ch.space.model.Cat;

public interface CatDao {

	Cat select(int cat_id);

	int randomCat(int cat_id);

}
