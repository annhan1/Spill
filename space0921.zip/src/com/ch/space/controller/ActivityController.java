package com.ch.space.controller;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.ch.space.service.JoinactService;
import com.ch.space.model.Activity;
import com.ch.space.service.ActivityService;

@Controller
public class ActivityController {
	
	@Autowired
	private ActivityService as;
	
	@Autowired
	private JoinactService js;

	/*
	 * @RequestMapping("list")//!member_id를 받아서 getTotal()파라미터로 전달해야함 public String
	 * list(Criteria cri, Model model) { model.addAttribute("list",
	 * as.getList(cri)); int total = as.getTotal(cri);
	 * model.addAttribute("pageMaker", new PageDTO(cri, total)); return
	 * "activity/list"; }
	 */
	@RequestMapping("activityInsertForm")//member_id를 받아서
	public String activityInsertForm(@RequestParam("member_id") int member_id, Model model) {
		model.addAttribute("member_id", member_id);//jsp페이지에 member_id를 전달
		return "activity/activityInsertForm";
	}
	@RequestMapping("activityInsert")//!activity 입력 후 joinact에도 입력해야함. joinact로 전달해야 하는 파라미터 : 입력된 activity_id, activity_host_id 
	public String activityInsert(Activity activity, HttpSession session, MultipartHttpServletRequest mhs, Model model) throws IOException, ParseException {
		
		String real = session.getServletContext().getRealPath("/resources/upload");
		List<MultipartFile> list = mhs.getFiles("file");
		
		List<String> fileList = new ArrayList<String>();
		for(MultipartFile mf : list) {
			String fileName = mf.getOriginalFilename();
			fileList.add(fileName);
			FileOutputStream fos = new FileOutputStream(new File(real+"/"+fileName));
			fos.write(mf.getBytes());
			fos.close();
		}
		
		//대표 이미지 지정
		activity.setActivity_img(fileList.get(0));		
		
		//!전체 이미지 img table에 insert 해야함
		
		as.insert(activity);
		
		System.out.println(activity.getActivity_host_id());
		Activity newAct = as.selectRecent(activity.getActivity_host_id());
		js.insert(newAct);
		
		return "redirect:yourspace?member_id="+activity.getActivity_host_id();
	}
	
	@RequestMapping("activityDetail")
	public String activityDetail(@RequestParam("activity_id") int activity_id, Model model) {
		model.addAttribute("activity", as.getDetail(activity_id));
		return "activity/activityDetail";
	}
	
	
}


