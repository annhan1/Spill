package com.ch.space.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ch.space.model.Choice;
import com.ch.space.model.Quiz;
import com.ch.space.service.ChoiceService;
import com.ch.space.service.ConnService;
import com.ch.space.service.HistoryService;
import com.ch.space.service.MemberService;
import com.ch.space.service.QuizService;

@Controller
public class MainController {
	
	@Autowired
	private QuizService qs;
	
	@Autowired
	private ChoiceService chs;
	
	@Autowired
	private MemberService ms;
	
	@Autowired
	private ConnService cs;
	
	@Autowired
	private HistoryService hs;
	
	@RequestMapping("/main")
	public String main(Model model) {
		
		// generating random level 1 quiz
		Quiz quiz = qs.randomQuiz();
		List<Choice> choiceList = chs.selectByQuiz(quiz.getQuiz_id());
		
		// calculating number of members and number of friendships created
		int memNum = ms.count();
		int hisNum = hs.count();
		int connNum = cs.count();
		
		model.addAttribute("quiz", quiz);
		model.addAttribute("choiceList", choiceList);
		model.addAttribute("memNum", memNum);
		model.addAttribute("hisNum", hisNum);
		model.addAttribute("connNum", connNum);
		
		return "main/main";
	}
}


