package com.ch.space.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.space.dao.ActivityDao;
import com.ch.space.model.Activity;

@Service
public class ActivityServiceImpl implements ActivityService{
	
	@Autowired
	private ActivityDao ad;

	@Override
	public List<Activity> getList(Map<String, Object> map) {
		List<Activity> list = ad.getList(map);
		for (Activity activity: list) {
			activity.setCnt_reply(ad.cnt_reply(activity.getActivity_id()));
			activity.setCnt_joiner(ad.cnt_joiner(activity.getActivity_id()));
		} 
		return list;
	}
	
	@Override
	public int getTotal(Criteria cri) {
		return ad.getTotal(cri);
	}

	@Override
	public void insert(Activity activity) {
		ad.insert(activity);	
	}

	@Override
	public Activity getDetail(int activity_id) {
		return ad.getDetail(activity_id);
	}

	@Override
	public Activity selectRecent(int activity_host_id) {
		return ad.selectRecent(activity_host_id);
	}

}
