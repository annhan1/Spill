package com.ch.space.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.space.dao.ConnDao;
import com.ch.space.model.Conn;

@Service
public class ConnServiceImpl implements ConnService {
	
	@Autowired
	private ConnDao cd;

	@Override
	public int count() {
		return cd.count();
	}

	@Override
	public int insert(Conn conn) {
		return cd.insert(conn);
	}
}
