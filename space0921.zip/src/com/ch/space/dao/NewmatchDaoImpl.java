package com.ch.space.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ch.space.model.Newmatch;

@Repository
public class NewmatchDaoImpl implements NewmatchDao {
	
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public void insert(Newmatch nm) {
		sst.insert("newmatchns.insert", nm);
	}

	@Override
	public List<Newmatch> selectMatched(int member_id) {
		return sst.selectList("newmatchns.selectMatched", member_id);
	}

	@Override
	public int updateDel(Newmatch nm) {
		return sst.update("newmatchns.updateDel", nm);
	}
}
