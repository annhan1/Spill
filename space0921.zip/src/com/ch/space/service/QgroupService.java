package com.ch.space.service;

import java.util.List;

import com.ch.space.model.Qgroup;

public interface QgroupService {
	
	List<Qgroup> list(int member_id);

	int insertMain(Qgroup qgroup);

	Qgroup selectRecent(String ip);

	Qgroup select(int qgroup_id);

	void updateMemInfo(Qgroup qgroup);

}
