package com.ch.space.model;

import java.sql.Date;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class Post {
	private int post_id;
	private int post_position;
	private int post_writer_id;
	private String post_content;
	private String post_img;
	private Date post_reg_date;
	private String post_del;
	// upload 용
		private MultipartFile file;
}
