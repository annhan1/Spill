package com.ch.space.service;

import com.ch.space.model.Conn;

public interface ConnService {

	int count();

	int insert(Conn conn);

}
