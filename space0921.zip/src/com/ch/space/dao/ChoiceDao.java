package com.ch.space.dao;

import java.util.List;

import com.ch.space.model.Choice;

public interface ChoiceDao {

	List<Choice> selectByQuiz(int quiz_id);

}
