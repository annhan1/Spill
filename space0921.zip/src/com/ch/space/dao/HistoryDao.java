package com.ch.space.dao;

import java.util.List;

import com.ch.space.model.History;
import com.ch.space.model.Qgroup;

public interface HistoryDao {

	List<History> listByCat(Qgroup qgroup);

	int sameCatAnswered(int member_id);

	int count();

	int insert(History history);

	int countAnswered(int qgroup_id);
	
}
