package com.ch.space.dao;

import java.util.List;

import com.ch.space.model.Quiz;

public interface QuizDao {

	List<Quiz> listByCat(int cat_id);

	Quiz randomQuiz();

	Quiz select(int quiz_id);

	Quiz randomQuiz(Quiz quiz);

	List<Quiz> questionsAnswered(int qgroup_id);

}
