package com.ch.space.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ch.space.model.Conn;

@Repository
public class ConnDaoImpl implements ConnDao {
	
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public int count() {
		return sst.selectOne("connns.count");
	}

	@Override
	public int insert(Conn conn) {
		return sst.insert("connns.insert", conn);
	}
}
