package com.ch.space.model;

import lombok.Data;

@Data
public class Alert {
	private int alert_id;
	private int member_id;
	private String alert_content;
	private String alert_link;
	private String alert_check;
}
