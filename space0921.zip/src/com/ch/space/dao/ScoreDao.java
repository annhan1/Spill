package com.ch.space.dao;

import java.util.List;

import com.ch.space.model.Score;

public interface ScoreDao {

	Score selectByCatMem(Score newScore);

	int update(Score newScore);

	int insert(Score newScore);

	List<Score> list(int member_id);

	List<Score> listSelectively(Score score);

	List<Score> listEveryone(Score score);

	List<Score> listNewMatchesDeclined(Score score);

}
