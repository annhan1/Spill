package com.ch.space.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.space.dao.MemberDao;
import com.ch.space.model.Member;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	private MemberDao md;

	@Override
	public Member select(int member_id) {
		return md.select(member_id);
	}

	@Override
	public int count() {
		return md.count();
	}

	@Override
	public int insert(Member member) {
		return md.insert(member);
	}

	@Override
	public int update(Member member) {
		return md.update(member);
	}

	@Override
	public int delete(String member_email) {
		return md.delete(member_email);
	}

	@Override
	public Member select1(String member_nickname) {
		return md.select1(member_nickname);
	}

	@Override
	public Member select2(String member_tel) {
		return md.select2(member_tel);
	}

	@Override
	public Member find(String member_email) {
		return md.find(member_email);
	}

	@Override
	public Member selectEmail(String member_email) {
		return md.selectEmail(member_email);
	}
	
	@Override
	public Member getDetail(int member_id) {
		return md.getDetail(member_id);
	}
}
