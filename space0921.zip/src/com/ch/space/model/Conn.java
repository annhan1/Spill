package com.ch.space.model;

import java.sql.Date;

import lombok.Data;

@Data
public class Conn {
	private int conn_friend1_id;
	private int conn_friend2_id;
	private Date conn_reg_date;
	private String conn_del;
}
