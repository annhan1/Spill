package com.ch.space.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.space.dao.QuizDao;
import com.ch.space.model.Quiz;

@Service
public class QuizServiceImpl implements QuizService {
	
	@Autowired
	private QuizDao qd;

	@Override
	public List<Quiz> listByCat(int cat_id) {
		return qd.listByCat(cat_id);
	}

	@Override
	public Quiz randomQuiz() {
		return qd.randomQuiz();
	}

	@Override
	public Quiz select(int quiz_id) {
		return qd.select(quiz_id);
	}

	@Override
	public Quiz randomQuiz(Quiz quiz) {
		return qd.randomQuiz(quiz);
	}

	@Override
	public List<Quiz> questionsAnswered(int qgroup_id) {
		return qd.questionsAnswered(qgroup_id);
	}
}
