package com.ch.space.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.space.dao.PostDao;
import com.ch.space.model.Post;

@Service
public class PostServiceImpl implements PostService{
	@Autowired
	private PostDao pd;

	@Override
	public Post getPost1(int member_id) {
		return pd.getPost1(member_id);
	}

	@Override
	public Post getPost2(int member_id) {
		return pd.getPost2(member_id);
	}

	@Override
	public Post getPost3(int member_id) {
		return pd.getPost3(member_id);
	}

	@Override
	public Post getPost4(int member_id) {
		return pd.getPost4(member_id);
	}

	@Override
	public Post getPost5(int member_id) {
		return pd.getPost5(member_id);
	}

	@Override
	public Post getPost6(int member_id) {
		return pd.getPost6(member_id);
	}

	@Override
	public void update(Post post) {
		pd.insert(post);
	}

	
}
