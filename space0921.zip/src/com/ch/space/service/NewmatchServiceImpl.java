package com.ch.space.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.space.dao.NewmatchDao;
import com.ch.space.model.Newmatch;

@Service
public class NewmatchServiceImpl implements NewmatchService {
	
	@Autowired
	private NewmatchDao nd;

	@Override
	public void insert(Newmatch nm) {
		nd.insert(nm);
	}

	@Override
	public List<Newmatch> selectMatched(int member_id) {
		return nd.selectMatched(member_id);
	}

	@Override
	public int updateDel(Newmatch nm) {
		return nd.updateDel(nm);
	}
}
