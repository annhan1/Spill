package com.ch.space.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ch.space.model.Quiz;

@Repository
public class QuizDaoImpl implements QuizDao {
	
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public List<Quiz> listByCat(int cat_id) {
		return sst.selectList("quizns.listByCat", cat_id);
	}

	@Override
	public Quiz randomQuiz() {
		return sst.selectOne("quizns.randomQuiz");
	}

	@Override
	public Quiz select(int quiz_id) {
		return sst.selectOne("quizns.select", quiz_id);
	}

	@Override
	public Quiz randomQuiz(Quiz quiz) {
		return sst.selectOne("quizns.randomQuizCat",quiz);
	}

	@Override
	public List<Quiz> questionsAnswered(int qgroup_id) {
		return sst.selectList("quizns.questionsAnswered", qgroup_id);
	}
}
