package com.ch.space.dao;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ch.space.model.Activity;
import com.ch.space.service.Criteria;

@Repository
public class ActivityDaoImpl implements ActivityDao{
	
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public List<Activity> getList(Map<String, Object> map) {
		return sst.selectList("activityns.getList",map);
	}

	@Override
	public int getTotal(Criteria cri) {
		return sst.selectOne("activityns.getTotal",cri);
	}

	@Override
	public void insert(Activity activity) {
		sst.insert("activityns.insert", activity);
	}

	@Override
	public Activity getDetail(int activity_id) {
		return sst.selectOne("activityns.detail", activity_id);
	}

	@Override
	public Activity selectRecent(int activity_host_id) {
		return sst.selectOne("activityns.selectRecent", activity_host_id);
	}

	@Override
	public int cnt_reply(int activity_id) {
		return sst.selectOne("activityns.replyCnt",activity_id);
	}

	@Override
	public int cnt_joiner(int activity_id) {
		return sst.selectOne("activityns.joinerCnt",activity_id);
	}

	
}
