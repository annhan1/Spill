package com.ch.space.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ch.space.model.Qgroup;

@Repository
public class QgroupDaoImpl implements QgroupDao {
	
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public List<Qgroup> list(int member_id) {
		return sst.selectList("qgroupns.list", member_id);
	}

	@Override
	public int insertMain(Qgroup qgroup) {
		return sst.insert("qgroupns.insertMain", qgroup);
	}

	@Override
	public Qgroup selectRecent(String ip) {
		return sst.selectOne("qgroupns.selectRecent",ip);
	}

	@Override
	public Qgroup select(int qgroup_id) {
		return sst.selectOne("qgroupns.select", qgroup_id);
	}

	@Override
	public Object updateMemInfo(Qgroup qgroup) {
		return sst.update("qgroupns.updateMemInfo", qgroup);
	}
}
