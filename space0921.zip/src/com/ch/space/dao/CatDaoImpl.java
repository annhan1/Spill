package com.ch.space.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ch.space.model.Cat;

@Repository
public class CatDaoImpl implements CatDao {
	
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public Cat select(int cat_id) {
		return sst.selectOne("catns.select", cat_id);
	}

	@Override
	public int randomCat(int cat_id) {
		return sst.selectOne("catns.randomCat", cat_id);
	}
}
