package com.ch.space.model;

import java.sql.Date;

import lombok.Data;

@Data
public class History {
	private int history_id;
	private int qgroup_id;
	private int choice_id;
	private Date history_reg_date;
	
	// 코딩용
	private int quiz_id;
	private int choice_point;
}
