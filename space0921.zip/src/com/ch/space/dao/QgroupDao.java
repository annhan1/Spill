package com.ch.space.dao;

import java.util.List;

import com.ch.space.model.Qgroup;

public interface QgroupDao {
	
	List<Qgroup> list(int member_id);

	int insertMain(Qgroup qgroup);

	Qgroup selectRecent(String ip);

	Qgroup select(int qgroup_id);

	Object updateMemInfo(Qgroup qgroup);

}
