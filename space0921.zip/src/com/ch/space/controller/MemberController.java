package com.ch.space.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ch.space.model.Activity;
import com.ch.space.model.Post;
import com.ch.space.service.ActivityService;
import com.ch.space.service.Criteria;
import com.ch.space.service.MemberService;
import com.ch.space.service.PageDTO;
import com.ch.space.service.PostService;

@Controller
public class MemberController {
	@Autowired
	private MemberService ms;
	@Autowired
	private PostService ps;
	@Autowired
	private ActivityService as;
	
	@RequestMapping("yourspace")
	public String yourspace(@RequestParam("member_id") int member_id, Criteria cri, Model model) {
		model.addAttribute("member", ms.getDetail(member_id));
		
		model.addAttribute("post1", ps.getPost1(member_id));
		model.addAttribute("post2", ps.getPost2(member_id));
		model.addAttribute("post3", ps.getPost3(member_id));
		model.addAttribute("post4", ps.getPost4(member_id));
		model.addAttribute("post5", ps.getPost5(member_id));
		model.addAttribute("post6", ps.getPost6(member_id));
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("member_id", member_id);
		map.put("cri", cri); 
		List<Activity> list = as.getList(map);
		model.addAttribute("list", list);

		int total = as.getTotal(cri);
		
		model.addAttribute("pageMaker", new PageDTO(cri, total));
		
		return "member/yourspace";
	}
	
	@RequestMapping("station")
	public String station() {
		return "member/station";
	}
	
	@RequestMapping("updatePost")
	public String updatePost(Post post, Model model, HttpSession session) throws IllegalStateException, IOException {
		String fileName = post.getFile().getOriginalFilename();
		
		String real = session.getServletContext().getRealPath("/resources/upload");
		FileOutputStream fos = new FileOutputStream(new File(real+"/"+fileName));
		fos.write(post.getFile().getBytes());
		fos.close();
		
		//post 이미지 지정
		post.setPost_img(fileName);	
		
		System.out.println(post.getPost_img());
		
		ps.update(post);
		model.addAttribute("member_id", post.getPost_writer_id());
		System.out.println("updatepost");
		return "redirect:yourspace";
	}

}


