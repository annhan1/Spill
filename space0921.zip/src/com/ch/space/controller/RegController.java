package com.ch.space.controller;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ch.space.model.Member;
import com.ch.space.model.Qgroup;
import com.ch.space.service.MemberService;
import com.ch.space.service.QgroupService;

@Controller
public class RegController {
	
	@Autowired
	private MemberService ms;
	
	@Autowired
	private QgroupService qgs;
	
	@RequestMapping("/joinForm")
	public String joinForm() {
		return "redirect:/joinForm/0/0";
	}
	@RequestMapping("/joinForm/{qgroup_id_old}/{qgroup_id_new}")
	public String joinForm(@PathVariable String qgroup_id_old, @PathVariable String qgroup_id_new, Model model) {
		model.addAttribute("qgroup_id_old", qgroup_id_old);
		model.addAttribute("qgroup_id_new", qgroup_id_new);
		return "/reg/joinForm";
	}
	@RequestMapping("/joinEmail")
	public String joinForm(String email, Model model) {
		model.addAttribute("email",email);
		return "/reg/joinForm";
	}
	
	@RequestMapping(value="/member_EmailChk",produces="text/html;charset=utf-8")
	@ResponseBody
	public String member_idChk(String member_email) {
		String blankid = "";
		Member member = ms.selectEmail(member_email);
		if (member == null) blankid="사용 가능한 아이디 입니다.";
		else blankid ="사용 중인 아이디 입니다. 다른 아이디를 사용하세요.";
		return blankid;
	}
	
	@RequestMapping(value="/member_TelChk",produces="text/html;charset=utf-8")
	@ResponseBody
	public String member_TelChk(String member_tel) {
		String blanktel = "";
		Member member = ms.select2(member_tel);
		if (member == null) blanktel="사용 가능한 전화번호 입니다.";
		else blanktel ="사용 중인 전화번호 입니다. 다른 닉네임을 사용하세요.";
		return blanktel;
	}
	
	@RequestMapping(value="/member_NicknameChk",produces="text/html;charset=utf-8")
	@ResponseBody
	public String member_NicknameChk(String member_nickname) {
		String blanknickname = "";
		Member member = ms.select2(member_nickname);
		if (member == null) blanknickname="사용 가능한 닉네임 입니다.";
		else blanknickname ="사용 중인 닉네임 입니다. 다른 닉네임을 사용하세요.";
		return blanknickname;
	}
	
	@RequestMapping(value="/join", method=RequestMethod.POST)
	public String join(String qgroup_id_old, String qgroup_id_new, 
			Member member, Model model, HttpSession session) throws IOException{
		
		int result = 0;
		System.out.println(member.getMember_email());
		Member mem = ms.selectEmail(member.getMember_email());
		
		// create account with given information
		if (mem == null) {
			String member_img= member.getFile().getOriginalFilename();
			member.setMember_img(member_img);
			String real= session.getServletContext().getRealPath("/resources/upload");
			FileOutputStream fos=
					new FileOutputStream(new File(real+"/"+member_img));
			fos.write(member.getFile().getBytes());
			fos.close();			
			result = ms.insert(member);
		} else result = -1;
		
		// update qgroup to include newly created member_id
		if (!qgroup_id_old.equals("0") && !qgroup_id_new.equals("0") && 
				qgroup_id_old!=null && qgroup_id_new!=null && result>0) {
			
			Member memberQuiz = ms.selectEmail(member.getMember_email());
			
			Qgroup qgroup = new Qgroup();
			qgroup.setMember_id(memberQuiz.getMember_id());
			qgroup.setQgroup_id(Integer.parseInt(qgroup_id_old));
			qgs.updateMemInfo(qgroup);
			
			qgroup.setQgroup_id(Integer.parseInt(qgroup_id_new));
			qgs.updateMemInfo(qgroup);
			
			model.addAttribute("qgroup_id_old", qgroup_id_old);
			model.addAttribute("member_id", memberQuiz.getMember_id());
		}
		
		model.addAttribute("result",result);
		return "/reg/join";
	}
	
	@RequestMapping("/loginForm")
	public String loginForm() {
		return "/reg/loginForm";
	}
	
	@RequestMapping("/login")
	public String login(Member member,Model model,HttpSession session) {
		int result = 0;
		Member mem =ms.selectEmail(member.getMember_email());
		if (mem == null || mem.getMember_del().equals("y")) result = -1;
		else if (mem.getMember_pass().equals(member.getMember_pass())) {
			result = 1;
			session.setAttribute("member_email", member.getMember_email());
		}
		model.addAttribute("result",result);
		return "/reg/login";
	}
	
	@RequestMapping("/forget")
	public String forget() {
		return "/reg/forget";
	}
	
	@RequestMapping(value="/member_lookingForName",produces="text/html;charset=utf-8")
	@ResponseBody
	public String member_lookingForId(String member_name) {
		String lookingforName = "";
		Member member = ms.select1(member_name);
		if (member == null) lookingforName="존재하는 하지 않는 이름 입니다.";
		else lookingforName ="존재 하는 이름 입니다.";
		return lookingforName;
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "/reg/logout";
	}
	
	@RequestMapping("/reg/main")
	public String main(Model model,HttpSession session) {
		String member_email =(String)session.getAttribute("member_email");
		Member member = null;
		if (member_email != null && !member_email.equals(""))
			 member = ms.selectEmail(member_email);
		model.addAttribute("member",member);
		return "/reg/main";
	}
	
	@RequestMapping("/reg/updateForm")
	public String update(Model model,HttpSession session) {
		String member_email =(String)session.getAttribute("member_email");
		Member member = ms.selectEmail(member_email);
		model.addAttribute("member",member);
		return "/reg/updateForm";
	}
	
	@RequestMapping("/reg/update")
	public String update(Member member,Model modle,HttpSession session) throws IOException {
		
		String member_img =member.getFile().getOriginalFilename();
		
		if(member_img!=null && !member_img.equals("")) {
			String real=session.getServletContext()
					.getRealPath("/upload");
			FileOutputStream fos =new FileOutputStream(
					new File(real+"/"+member_img));
			fos.write(member.getFile().getBytes());
			fos.close();
			member.setMember_img(member_img);
		}
		int result =ms.update(member);
		modle.addAttribute("result", result);
		
		return "/reg/update";
	}
	
	@RequestMapping("/reg/delete")
	public String delete(Model model,HttpSession session) {
	String member_email =(String) session.getAttribute("member_email");
		int result = ms.delete(member_email);
		
		if(result > 0) session.invalidate();
		
		model.addAttribute("result",result);
		return "/reg/delete";
	}
}


