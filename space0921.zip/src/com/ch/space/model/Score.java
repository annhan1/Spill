package com.ch.space.model;

import lombok.Data;

@Data
public class Score {
	private int score_id;
	private int member_id;
	private int cat_id;
	private String score_num;
	private String score_comp;
	
	// Data transfer
	private int newmatch_friend1_id;
	private int newmatch_friend2_id;
	private int conn_friend1_id;
	private int conn_friend2_id;
}
