package com.ch.space.model;

import lombok.Data;

@Data
public class Choice {
	private int choice_id;
	private int quiz_id;
	private String choice_content;
	private String choice_point;
}
