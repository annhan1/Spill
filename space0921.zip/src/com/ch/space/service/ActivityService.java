package com.ch.space.service;

import java.util.List;
import java.util.Map;

import com.ch.space.model.Activity;

public interface ActivityService {

	public List<Activity> getList(Map<String, Object> map);

	public int getTotal(Criteria cri);

	public void insert(Activity activity);

	public Activity getDetail(int activity_id);

	public Activity selectRecent(int activity_host_id);

}

  




