package com.ch.space.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ch.space.model.Member;

@Repository
public class MemberDaoImpl implements MemberDao {
	
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public Member select(int member_id) {
		return sst.selectOne("memberns.selectId", member_id);
	}

	@Override
	public int count() {
		return sst.selectOne("memberns.count");
	}
	
	@Override
	public int insert(Member member) {
		return sst.insert("memberns.insert",member);
	}
	
	@Override
	public int update(Member member) {
		return sst.update("memberns.update",member);
	}
	
	@Override
	public int delete(String member_email) {
		return sst.update("memberns.delete",member_email);
	}
	
	@Override
	public Member select1(String member_nickname) {
		return sst.selectOne("members.select1",member_nickname);
	}
	
	@Override
	public Member select2(String member_tel) {
		return sst.selectOne("memberns.select2",member_tel);
	}
	
	@Override
	public Member find(String member_name) {
		return sst.selectOne("memberns.selectName",member_name);
	}

	@Override
	public Member selectEmail(String member_email) {
		return sst.selectOne("memberns.selectEmail", member_email);
	}
	
	@Override
	public Member getDetail(int member_id) {
		return sst.selectOne("memberns.select", member_id);
	}

}
