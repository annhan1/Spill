package com.ch.space.model;

import java.sql.Date;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class Member {
	private int member_id;
	private String member_email;
	private String member_pass;
	private String member_name;
	private Date member_birth;
	private String member_tel;
	private String member_nickname;
	private String member_img;
	private String member_desc;
	private Date member_reg_date;
	private String member_alert;
	private String member_del;
	
	// file
	private MultipartFile file;
}
