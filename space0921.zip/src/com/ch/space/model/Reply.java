package com.ch.space.model;

import java.sql.Date;

import lombok.Data;

@Data
public class Reply {
	private int reply_id;
	private int activity_id;
	private int member_id;
	private String reply_content;
	private String reply_img;
	private Date reply_reg_date;
	private String reply_del;
}
