package com.ch.space.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.space.dao.CatDao;
import com.ch.space.model.Cat;

@Service
public class CatServiceImpl implements CatService {
	
	@Autowired
	private CatDao cd;

	@Override
	public Cat select(int cat_id) {
		return cd.select(cat_id);
	}

	@Override
	public int randomCat(int cat_id) {
		return cd.randomCat(cat_id);
	}
}
