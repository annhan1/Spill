package com.ch.space.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ch.space.model.Score;

@Repository
public class ScoreDaoImpl implements ScoreDao {
	
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public Score selectByCatMem(Score newScore) {
		return sst.selectOne("scorens.selectByCatMem", newScore);
	}

	@Override
	public int update(Score newScore) {
		return sst.update("scorens.update", newScore);
	}

	@Override
	public int insert(Score newScore) {
		return sst.insert("scorens.insert", newScore);
	}

	@Override
	public List<Score> list(int member_id) {
		return sst.selectList("scorens.list", member_id);
	}

	@Override
	public List<Score> listSelectively(Score score) {
		return sst.selectList("scorens.listSelectively",score);
	}

	@Override
	public List<Score> listEveryone(Score score) {
		return sst.selectList("scorens.listEveryone", score);
	}

	@Override
	public List<Score> listNewMatchesDeclined(Score score) {
		return sst.selectList("scorens.listNewMatches", score);
	}
}
