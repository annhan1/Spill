package com.ch.space.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ch.space.model.Post;

@Repository
public class PostDaoImpl implements PostDao{
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public Post getPost1(int member_id) {
		return sst.selectOne("postns.getPost1", member_id);
	}

	@Override
	public Post getPost2(int member_id) {
		return sst.selectOne("postns.getPost2", member_id);
	}

	@Override
	public Post getPost3(int member_id) {
		return sst.selectOne("postns.getPost3", member_id);
	}

	@Override
	public Post getPost4(int member_id) {
		return sst.selectOne("postns.getPost4", member_id);
	}

	@Override
	public Post getPost5(int member_id) {
		return sst.selectOne("postns.getPost5", member_id);
	}

	@Override
	public Post getPost6(int member_id) {
		return sst.selectOne("postns.getPost6", member_id);
	}

	@Override
	public void insert(Post post) {
		sst.insert("postns.insert", post);
	}

	
	
}
