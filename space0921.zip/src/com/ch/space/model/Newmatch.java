package com.ch.space.model;

import java.sql.Date;

import lombok.Data;

@Data
public class Newmatch {
	private int newmatch_friend1_id;
	private int newmatch_friend2_id;
	private Date newmatch_reg_date;
	private String newmatch_del;
}

