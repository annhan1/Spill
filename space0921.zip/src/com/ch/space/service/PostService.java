package com.ch.space.service;

import com.ch.space.model.Post;

public interface PostService {
	
	Post getPost1(int member_id);
	Post getPost2(int member_id);
	Post getPost3(int member_id);
	Post getPost4(int member_id);
	Post getPost5(int member_id);
	Post getPost6(int member_id);
	void update(Post post);

}
