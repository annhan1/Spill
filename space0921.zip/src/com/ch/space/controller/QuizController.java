package com.ch.space.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.ch.space.model.Choice;
import com.ch.space.model.History;
import com.ch.space.model.Qgroup;
import com.ch.space.model.Quiz;
import com.ch.space.service.CatService;
import com.ch.space.service.ChoiceService;
import com.ch.space.service.HistoryService;
import com.ch.space.service.QgroupService;
import com.ch.space.service.QuizService;


@Controller
public class QuizController {
	
	@Autowired 
	private QuizService qs;
		 
	@Autowired 
	private QgroupService qgs;
		 
	@Autowired
	private HistoryService hs;
		 
	@Autowired
	private ChoiceService chs;
	
	@Autowired
	private CatService cs;
	
	/*
	@RequestMapping("/quiz1/{member_id}")
	public String quiz(@PathVariable int member_id, Model model) {
		
		// generating random level 1 quiz
		Quiz quiz = qs.randomQuiz();
		List<Choice> choiceList = chs.selectByQuiz(quiz.getQuiz_id());
	 
		// create new quiz group
		Qgroup qgroupCreate = new Qgroup();
		qgroupCreate.setCat_id(quiz.getCat_id());
		qgroupCreate.setMember_id(member_id);
		int resultQgroupInsert = qgs.insertMain(qgroupCreate);
		
		String returnString = "";
		
		if (resultQgroupInsert > 0) {
			Qgroup qgroup = qgs.selectRecent(member_id);

			returnString += "quiz/quiz";

			// generate new question
			Quiz quizOld = new Quiz();
			quizOld.setCat_id(cat_id);
			Quiz quiz = qs.randomQuiz(quizOld);
			List<Choice> choiceList = chs.selectByQuiz(quiz.getQuiz_id());
			
			System.out.println("qgroup_id_old: "+qgroup_id);
			System.out.println("qgroup_id_new: "+qgroup.getQgroup_id());
			model.addAttribute("quizPath", "quiz2");
			model.addAttribute("quiz", quiz);
			model.addAttribute("choiceList", choiceList);
			model.addAttribute("qgroup_id",qgroup.getQgroup_id());	
			model.addAttribute("qgroup_id_old", qgroup_id);
		} else {
			 returnString += "error";
			 model.addAttribute("msg", "다시 한 번 시도해주세요.");
		}
		
		return returnString;
	}
 	*/
	@RequestMapping("/quiz1/{qgroup_id_old}/{qgroup_id}/{quiz_id}/{choice_id}")
	public String quiz(@PathVariable int qgroup_id, @PathVariable int quiz_id, 
		@PathVariable int choice_id, Model model) {
	 
		Quiz quizOld = qs.select(quiz_id);
	 
		Qgroup qgroup = new Qgroup();
		int resultQgroupInsert = 0;
	 
		if (qgroup_id<=0) {
		
			// create quiz group
			Qgroup qgroupCreate = new Qgroup();
			qgroupCreate.setCat_id(quizOld.getCat_id());
			
			// find ip of client and save to qgroup as temporary member id
			HttpServletRequest req = ((ServletRequestAttributes)RequestContextHolder.currentRequestAttributes()).getRequest();
			
			// WAS 는 보통 2차 방화벽 안에 있고 Web Server 를 통해 client 에서 호출되거나 cluster로 구성되어 
			// load balancer 에서 호출되는데 이럴 경우에서 getRemoteAddr() 을 호출하면 웹서버나 
			// load balancer의 IP 가 나옴.  X-Forwarded-For 값을 확인해서 있으면 이걸 사용하고 
			// 없으면 getRemoteAddr() 사용
			String ip = req.getHeader("X-FORWARDED-FOR");
			if (ip == null) ip = req.getRemoteAddr();
			qgroupCreate.setQgroup_temp_member(ip);
			
			resultQgroupInsert = qgs.insertMain(qgroupCreate);
			
			// if insert succeeded, find qgroup_id for most recent insert with ip as temporary member id
			if (resultQgroupInsert > 0) {
				qgroup = qgs.selectRecent(ip);
			}
		} else {
		 qgroup = qgs.select(qgroup_id);
		}
	 
		// save choice to history
		History history = new History();
		int resultHistoryInsert = 0;
	 
		if (qgroup!=null) {
			history.setChoice_id(choice_id);
			history.setQgroup_id(qgroup.getQgroup_id());
			resultHistoryInsert = hs.insert(history);
		}
	 
		String returnString = "";
	 
		if (resultHistoryInsert>0) {
		 
			// count how many histories with qgroup_id
			int questionsAnswered = hs.countAnswered(qgroup.getQgroup_id());
			 
			// if five questions answered, change category and ask questions
			if (questionsAnswered>=5) {
				returnString += "redirect:/quiz2/"+qgroup.getQgroup_id();
			} else {
				returnString += "quiz/quiz";
			 
				// record ids of questions answered before
				List<Quiz> quizLongList = qs.questionsAnswered(qgroup.getQgroup_id());
				List<Integer> quizList = new ArrayList<Integer>();

				for (Quiz q:quizLongList) {
					quizList.add(q.getQuiz_id());
				}
				quizOld.setQuizList(quizList);
			 
				// generate new question
				Quiz quiz = qs.randomQuiz(quizOld);
				List<Choice> choiceList = chs.selectByQuiz(quiz.getQuiz_id());
				
				model.addAttribute("quizPath", "quiz1");
				model.addAttribute("quiz", quiz);
				model.addAttribute("choiceList", choiceList);
				model.addAttribute("qgroup_id", qgroup.getQgroup_id());
				model.addAttribute("qgroup_id_old", 0);
			}
		} else {
		 returnString += "error";
		 model.addAttribute("msg", "다시 한 번 시도해주세요.");
		}
		
		return returnString;
	}
	
	@RequestMapping("/quiz2/{qgroup_id}")
	public String quiz2(@PathVariable int qgroup_id, Model model) {
		
		Qgroup qgroupOld = qgs.select(qgroup_id);
		
		// pick randomly new cat_id
		int cat_id = cs.randomCat(qgroupOld.getCat_id());
	 
		// create new quiz group
		Qgroup qgroupCreate = new Qgroup();
		qgroupCreate.setCat_id(cat_id);
		qgroupCreate.setQgroup_temp_member(qgroupOld.getQgroup_temp_member());
		int resultQgroupInsert = qgs.insertMain(qgroupCreate);
		
		String returnString = "";
		
		if (resultQgroupInsert > 0) {
			Qgroup qgroup = qgs.selectRecent(qgroupOld.getQgroup_temp_member());

			returnString += "quiz/quiz";

			// generate new question
			Quiz quizOld = new Quiz();
			quizOld.setCat_id(cat_id);
			Quiz quiz = qs.randomQuiz(quizOld);
			List<Choice> choiceList = chs.selectByQuiz(quiz.getQuiz_id());
			
			System.out.println("qgroup_id_old: "+qgroup_id);
			System.out.println("qgroup_id_new: "+qgroup.getQgroup_id());
			model.addAttribute("quizPath", "quiz2");
			model.addAttribute("quiz", quiz);
			model.addAttribute("choiceList", choiceList);
			model.addAttribute("qgroup_id",qgroup.getQgroup_id());	
			model.addAttribute("qgroup_id_old", qgroup_id);
		} else {
			 returnString += "error";
			 model.addAttribute("msg", "다시 한 번 시도해주세요.");
		}
		
		return returnString;
	}
 
	@RequestMapping("/quiz2/{qgroup_id_old}/{qgroup_id}/{quiz_id}/{choice_id}")
	public String quiz2(@PathVariable int qgroup_id_old, @PathVariable int qgroup_id, 
			@PathVariable int quiz_id, @PathVariable int choice_id, Model model) {
	 
		Quiz quizOld = qs.select(quiz_id);
		Qgroup qgroup = qgs.select(qgroup_id);
		
		// save choice to history
		History history = new History();
		int resultHistoryInsert = 0;
	 
		if (qgroup!=null) {
			history.setChoice_id(choice_id);
			history.setQgroup_id(qgroup.getQgroup_id());
			resultHistoryInsert = hs.insert(history);
		}
	 
		String returnString = "";
	 
		if (resultHistoryInsert>0) {
		 
			// count how many histories with qgroup_id
			int questionsAnswered = hs.countAnswered(qgroup.getQgroup_id());
			 
			// if five questions answered, change category and ask questions
			if (questionsAnswered>=5) {
				//find two
				returnString += "redirect:/joinForm/"+qgroup_id_old+"/"+qgroup.getQgroup_id();
			} else {
				returnString += "quiz/quiz";
			 
				// record ids of questions answered before
				List<Quiz> quizLongList = qs.questionsAnswered(qgroup.getQgroup_id());
				List<Integer> quizList = new ArrayList<Integer>();

				for (Quiz q:quizLongList) {
					quizList.add(q.getQuiz_id());
				}
				quizOld.setQuizList(quizList);
			 
				// generate new question
				Quiz quiz = qs.randomQuiz(quizOld);
				List<Choice> choiceList = chs.selectByQuiz(quiz.getQuiz_id());
				
				model.addAttribute("quizPath", "quiz2");
				model.addAttribute("quiz", quiz);
				model.addAttribute("choiceList", choiceList);
				model.addAttribute("qgroup_id", qgroup.getQgroup_id());
				model.addAttribute("qgroup_id_old", qgroup_id_old);
			}
		} else {
			returnString += "error";
			model.addAttribute("msg", "다시 한 번 시도해주세요.");
		}
		
		return returnString; 
	}
}


