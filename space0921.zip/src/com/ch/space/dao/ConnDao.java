package com.ch.space.dao;

import com.ch.space.model.Conn;

public interface ConnDao {

	int count();

	int insert(Conn conn);

}
